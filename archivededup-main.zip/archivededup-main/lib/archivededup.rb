require "archivededup/version"

module Archivededup
  class Error < StandardError; end
  # Your code goes here...
end
