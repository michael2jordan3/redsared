RSpec.describe Archivededup do
  it "has a version number" do
    expect(Archivededup::VERSION).not_to be nil
  end

  it "does something useful" do
    expect(true).to eq(true)
  end
end
